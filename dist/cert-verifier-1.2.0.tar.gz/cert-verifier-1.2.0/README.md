[![Build Status](https://travis-ci.org/blockchain-certificates/cert-verifier.svg?branch=master)](https://travis-ci.org/blockchain-certificates/cert-verifier)

# cert-verifier
library and service for verifying blockchain certificates

Initial repo for verification library and service. In progress.
